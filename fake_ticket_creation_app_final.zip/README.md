# Bulk Ticket Creation App (FOR DEMO/TRAINING USES ONLY)<br>

***UPDATES (Spring'21)***<br>
-- More themes!!!<br>
-- Include your own private Google Sheet!!!
<ol>
<li>Download the Zip folder from this github page</li>
<li>Install the Zip folder in your Zendesk Account</li>
<li>Create a Google Sheet (<a href="https://docs.google.com/spreadsheets/d/1nZW-z8pQ4ec5jxqpuJ06gn0U2R7Gs-6G3HmehDnAt3M/edit#gid=1461444737">sample</a>)</li>
 The Google Sheet format should be 3 columns (no header needed)
<ul>
<li>Column 1: Subject</li>
<li>Column 2: Description</li>
<li>Column 3: User Email (should probably use fake addresses)</li>
</ul>
  <strong>IMPORTANT: </strong>Share settings on the Sheet need to be set to "<strong>Anyone on the internet with this link can view</strong>"</li>
<li>Copy the Sheet ID from the URL (ex: 1nZW-z8pQ4ec5jxqpuJ06gn0U2R7Gs-6G3HmehDnAt3M)</li>
<li>Paste the Sheet ID into the Setting of the App</li>
<li>Name the ticket theme (whatever you want)</li>
The App is now ready to pull from your Sheet! You'll see it as an option at the bottom of the "Choose a Ticket Theme" dropdown.<br>
<strong>RECOMMENDATION/REMINDER: disable your Triggers that send email notifications before using this app!!!</strong>
</ol>
________________________________________________<br>
<br>

This ticket sidebar app creates fake tickets in bulk. 

Commonly used for... 

<ul>
  <li>staging trial / demo accounts</li>
  <li>training for new Agents</li>
  <li>general testing</li>
</ul>  


<span style="color:red;font-size:20px;"> NOTE: you'll likely want to <strong>disable any Triggers and/or Automations before performing an import</strong>. To prevent bulk notifications/emails to be sent out.</span> 

### Screenshot(s):
<img src="https://theme.zdassets.com/theme_assets/725179/1ace389cd6000429839069a84917bcd2dce79f3d.gif" alt="demo" style="width:500px;">

FULL DISCLOSURE: Much of the code for this app was "borrowed" from an existing app. [training-tickets-creator-app](https://github.com/ZendeskES/training-tickets-creator-app). The developer of that app deserves significant credit. 